<!DOCTYPE html>
<html>

<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<title>Регистрация</title>

	<link href="<?php echo base_url();?>assets/css/old/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/build/css/intlTelInput.css">
    <link href="<?php echo base_url();?>assets/css/metisMenu.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/sb-admin-2.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/morris.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">


    <script src="http://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

</head>

<body>