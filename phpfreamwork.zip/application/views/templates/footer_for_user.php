	
	<script src="http://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="<?php echo base_url();?>assets/js/old/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/metisMenu.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/raphael.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/morris.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/morris-data.js"></script>
    <script src="<?php echo base_url();?>assets/js/sb-admin-2.js"></script>

</body>

</html>